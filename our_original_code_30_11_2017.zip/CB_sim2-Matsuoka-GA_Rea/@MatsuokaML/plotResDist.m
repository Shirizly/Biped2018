function plotResDist(obj, dist)
%PLOTRESDIST Summary of this function goes here
%   Detailed explanation goes here

    
end

