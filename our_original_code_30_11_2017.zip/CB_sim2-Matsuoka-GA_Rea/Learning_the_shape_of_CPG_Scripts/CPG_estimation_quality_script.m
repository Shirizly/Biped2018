
% this script takes 2 CPG parameters and create a mesh. than, it's
% calculating: 1) real CPG output (using ML class)
%              2) estimated CPG output using NN
% than it clculates the MSE error between them and visualize that in color.

clear all; close all; clc;

%%
